var tablinks = document.getElementsByClassName("tab-links");
var tabcontents = document.getElementsByClassName("tab-contents");

function opentab(tabname) {
  for (let tablink of tablinks) {
    tablink.classList.remove("active-link");
  }

  for (let tabcontent of tabcontents) {
    tabcontent.classList.remove("active-tab");
  }

  event.currentTarget.classList.add("active-link");
  document.getElementById(tabname).classList.add("active-tab");
}

/* FORM VALIDATION */

function validateText() {
  let confirmation = confirm("You are about to submit your form!");
  if (confirmation == true) {
    let box = document.getElementById("name");
    let box2 = document.getElementById("address");
    let box3 = document.getElementById("email");
    let box4 = document.getElementById("phone");
    let box5 = document.getElementsByClassName("textarea");

    if (
      box.value == "" ||
      box2.value == "" ||
      box3.value == "" ||
      box4.value == "" ||
      Array.from(box5).some((textarea) => textarea.value == "")
    ) {
      alert("Kindly fill the required boxes before submitting");
      box.focus();
      box.style.border = "solid 3px red";
      return false;
    }
  }
}

